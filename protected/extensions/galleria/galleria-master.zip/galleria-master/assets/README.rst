********
Galleria
********

**Responsive JavaScript Image Gallery**

This is the open source repository for the Galleria core, the Classic theme, plugins and everything else that comes bundled with the free download.
Feel free to post issues - but keep them code related please. You may also do pull requests, but make sure you include some comments and/or tests.

Info, demos, docs and everything else: http://galleria.io

Updates via twitter: http://twitter.com/galleriajs

Non-code related issues and support: http://support.galleria.io

Documentation
=============

Documentation is currently available in `reST
<http://en.wikipedia.org/wiki/ReStructuredText>`_ format in the repository.

You can build local HTML using Sphinx: http://sphinx.pocoo.org/
