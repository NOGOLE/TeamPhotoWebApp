<?php

class GalleriaBehavior extends CBehavior
{
    public $imagePrefix;
    public $image;
    public $title;
    public $description;
}
